const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const touchControls = document.getElementById('touch-controls');
const btnPauseUI = document.getElementById('btn-pause-ui');

// Renderizado pixel art nítido
ctx.imageSmoothingEnabled = false;

// --- ESTADOS DEL JUEGO ('MENU', 'LEVEL_SELECT', 'SETTINGS', 'PLAYING', 'PAUSED', 'GAME_OVER') ---
let gameState = 'MENU'; 
let currentLevel = 1;
let coinsCollected = 0;
let showTouchControls = true;

// --- SISTEMA DE GUARDADO ---
let gameData = {
  hasSavedGame: false,
  unlockedLevels: 1
};

function loadSaveData() {
  const saved = localStorage.getItem('maicol_adventure_save');
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      gameData.hasSavedGame = parsed.hasSavedGame || false;
      gameData.unlockedLevels = parsed.unlockedLevels ? Math.max(1, parsed.unlockedLevels) : 1;
    } catch (e) {
      console.error('Error al cargar guardado:', e);
      gameData = { hasSavedGame: false, unlockedLevels: 1 };
    }
  } else {
    gameData = { hasSavedGame: false, unlockedLevels: 1 };
  }
}

function saveGame() {
  gameData.hasSavedGame = true;
  localStorage.setItem('maicol_adventure_save', JSON.stringify(gameData));
}

loadSaveData();

// --- MÚSICA ---
const menuMusic = new Audio('assets/music/MusicMenu.mp3');
menuMusic.loop = true;

function updateMusicState() {
  if (gameState === 'MENU' || gameState === 'SETTINGS' || gameState === 'LEVEL_SELECT') {
    if (menuMusic.paused) {
      menuMusic.play().catch(() => {});
    }
  } else {
    menuMusic.pause();
  }
}

window.addEventListener('click', () => { updateMusicState(); }, { once: true });
window.addEventListener('touchstart', () => { updateMusicState(); }, { once: true });

// --- POSICIONES Y CÁMARA ---
let spawnPoint = { x: 50, y: 200 };
const camera = { x: 0, y: 0 };
let levelWidth = 800;

// --- ASSETS ---
const logoImg = new Image(); logoImg.src = 'assets/portrait/logo.png';
const newGameBtnImg = new Image(); newGameBtnImg.src = 'assets/portrait/New_game.png';
const continueBtnImg = new Image(); continueBtnImg.src = 'assets/portrait/Continue.png';
const settingsBtnImg = new Image(); settingsBtnImg.src = 'assets/portrait/settings.png';
const maicolSheet = new Image(); maicolSheet.src = 'assets/characters/Maicol.png';
const auraImg = new Image(); auraImg.src = 'assets/characters/aura.png';

const blockImages = {
  1: new Image(), 2: new Image(), 3: new Image(), 4: new Image(),
  5: new Image(), 6: new Image(), 7: new Image(), 8: new Image()
};

blockImages[1].src = 'assets/Blocks/grass.png';
blockImages[2].src = 'assets/Blocks/dirt.png';
blockImages[3].src = 'assets/Blocks/skewers.png';
blockImages[4].src = 'assets/Blocks/coins.png';
blockImages[5].src = 'assets/Blocks/Box.png';
blockImages[6].src = 'assets/Blocks/door2.png'; 
blockImages[7].src = 'assets/Blocks/door1.png'; 
blockImages[8].src = 'assets/Blocks/spawn.png';

// --- SPRITESHEET JUGADOR ---
const frames = {
  idle: [{ x: 809, y: 0, w: 404, h: 715 }],
  walk: [
    { x: 405, y: 0, w: 404, h: 716 },
    { x: 404, y: 720, w: 404, h: 712 },
    { x: 0, y: 720, w: 404, h: 714 },
    { x: 1617, y: 0, w: 404, h: 710 },
    { x: 1213, y: 0, w: 404, h: 714 },
    { x: 808, y: 720, w: 404, h: 712 },
    { x: 1213, y: 0, w: 404, h: 714 },
    { x: 1212, y: 720, w: 404, h: 710 }
  ],
  jump: [{ x: 0, y: 0, w: 405, h: 720 }]
};

// --- JUGADOR ---
const player = {
  x: 50, y: 200, width: 46, height: 86,
  vx: 0, vy: 0, speed: 4.5, jumpForce: -9.5, gravity: 0.5,
  grounded: false, facingRight: true, animFrame: 0, animTimer: 0,
  heldBlock: null, jumpCount: 0, maxJumps: 2
};

let platforms = [], hazards = [], coins = [], grabables = [], doors = [], spawnBlocks = [];

function killPlayer() {
  gameState = 'GAME_OVER';
  updateMusicState();
}

function restartLevel() {
  player.x = spawnPoint.x;
  player.y = spawnPoint.y;
  player.vx = 0;
  player.vy = 0;
  player.jumpCount = 0;
  
  if (player.heldBlock) {
    player.heldBlock.isCarried = false;
    player.heldBlock = null;
  }
  
  loadLevelTXT(currentLevel);
  gameState = 'PLAYING';
  updateMusicState();
}

function loadLevelTXT(levelNum) {
  currentLevel = levelNum;
  fetch(`Levels/level${levelNum}.txt`)
    .then(res => res.text())
    .then(textData => {
      platforms = []; hazards = []; coins = []; grabables = []; doors = []; spawnBlocks = [];
      const rows = textData.trim().split('\n');
      let maxCols = 0;

      rows.forEach((row, rowIndex) => {
        if (row.length > maxCols) maxCols = row.length;
        for (let colIndex = 0; colIndex < row.length; colIndex++) {
          const char = row[colIndex];
          const posX = colIndex * 32;
          const posY = rowIndex * 32;

          if (char === 'G') platforms.push({ x: posX, y: posY, w: 32, h: 32, type: 1 });
          else if (char === 'T' || char === 'W') platforms.push({ x: posX, y: posY, w: 32, h: 32, type: 2 });
          else if (char === 'P') hazards.push({ x: posX, y: posY, w: 32, h: 32 });
          else if (char === 'C') coins.push({ x: posX, y: posY, w: 32, h: 32, collected: false });
          else if (char === 'B') grabables.push({ x: posX, y: posY, w: 32, h: 32, isCarried: false, vy: 0 });
          else if (char === 'D') doors.push({ x: posX, y: posY, w: 32, h: 32, type: 6 });
          else if (char === 'F') doors.push({ x: posX, y: posY, w: 32, h: 32, type: 7 });
          else if (char === 'S' || char === 's') {
            spawnBlocks.push({ x: posX, y: posY, w: 32, h: 32 });
            spawnPoint = { x: posX, y: posY - (player.height - 32) };
          }
        }
      });
      levelWidth = maxCols * 32;
      player.x = spawnPoint.x;
      player.y = spawnPoint.y;
      player.vx = 0; player.vy = 0;
    })
    .catch(() => {
      spawnPoint = { x: 50, y: 200 };
      player.x = spawnPoint.x;
      player.y = spawnPoint.y;
    });
}

loadLevelTXT(1);

// --- CONTROLES TECLADO ---
const keys = { left: false, right: false, jump: false };

function performJump() {
  if (player.grounded || player.jumpCount < player.maxJumps) {
    player.vy = player.jumpForce;
    player.grounded = false;
    player.jumpCount++;
  }
}

function toggleGrabBlock() {
  if (player.heldBlock) {
    player.heldBlock.isCarried = false;
    player.heldBlock.vy = 0;
    player.heldBlock = null;
  } else {
    for (let b of grabables) {
      const dist = Math.hypot((player.x + player.width / 2) - (b.x + b.w / 2), (player.y + player.height / 2) - (b.y + b.h / 2));
      if (dist < 75 && !b.isCarried) {
        b.isCarried = true;
        player.heldBlock = b;
        break;
      }
    }
  }
}

window.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft' || e.key === 'a') keys.left = true;
  if (e.key === 'ArrowRight' || e.key === 'd') keys.right = true;
  if (e.key === 'ArrowUp' || e.key === 'w' || e.key === ' ') {
    if (!keys.jump && gameState === 'PLAYING') performJump();
    keys.jump = true;
  }
  if (e.key === 'e' || e.key === 'E') toggleGrabBlock();
  if (e.key === 'r' || e.key === 'R') {
    if (gameState === 'PLAYING' || gameState === 'GAME_OVER') restartLevel();
  }
  if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') togglePause();
});

window.addEventListener('keyup', (e) => {
  if (e.key === 'ArrowLeft' || e.key === 'a') keys.left = false;
  if (e.key === 'ArrowRight' || e.key === 'd') keys.right = false;
  if (e.key === 'ArrowUp' || e.key === 'w' || e.key === ' ') keys.jump = false;
});

function togglePause(e) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }
  if (gameState === 'PLAYING') gameState = 'PAUSED';
  else if (gameState === 'PAUSED') gameState = 'PLAYING';
  updateMusicState();
}

if (btnPauseUI) {
  btnPauseUI.addEventListener('touchstart', togglePause);
  btnPauseUI.addEventListener('click', togglePause);
}

function setupTouch(id, action) {
  const btn = document.getElementById(id);
  if (!btn) return;
  btn.addEventListener('touchstart', (e) => { e.preventDefault(); action(true); });
  btn.addEventListener('touchend', (e) => { e.preventDefault(); action(false); });
  btn.addEventListener('mousedown', () => action(true));
  btn.addEventListener('mouseup', () => action(false));
}

setupTouch('btn-left', (val) => keys.left = val);
setupTouch('btn-right', (val) => keys.right = val);
setupTouch('btn-jump', (val) => { if (val && !keys.jump && gameState === 'PLAYING') performJump(); keys.jump = val; });
setupTouch('btn-grab', (val) => { if (val) toggleGrabBlock(); });

// --- INTERACCIÓN EN MENÚS ---
function handleCanvasInteraction(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  
  const clickX = (clientX - rect.left) * scaleX;
  const clickY = (clientY - rect.top) * scaleY;

  if (gameState === 'MENU') {
    if (clickX >= 530 && clickX <= 770 && clickY >= 180 && clickY <= 240) {
      gameData.hasSavedGame = true;
      gameData.unlockedLevels = 1;
      saveGame();
      loadLevelTXT(1);
      gameState = 'PLAYING';
      updateMusicState();
    } 
    else if (clickX >= 530 && clickX <= 770 && clickY >= 250 && clickY <= 310) {
      if (gameData.hasSavedGame) {
        gameState = 'LEVEL_SELECT';
        updateMusicState();
      }
    } 
    else if (clickX >= 530 && clickX <= 770 && clickY >= 320 && clickY <= 380) {
      gameState = 'SETTINGS';
      updateMusicState();
    }
  } else if (gameState === 'LEVEL_SELECT') {
    if (clickX >= 15 && clickX <= 135 && clickY >= 15 && clickY <= 60) {
      gameState = 'MENU';
      updateMusicState();
      return;
    }
    const startX = 100, startY = 80, btnSize = 50, gap = 12;
    for (let i = 0; i < 50; i++) {
      const col = i % 10, row = Math.floor(i / 10);
      const bx = startX + col * (btnSize + gap), by = startY + row * (btnSize + gap);
      if (clickX >= bx && clickX <= bx + btnSize && clickY >= by && clickY <= by + btnSize) {
        if (i + 1 <= gameData.unlockedLevels) {
          loadLevelTXT(i + 1);
          gameState = 'PLAYING';
          updateMusicState();
        }
      }
    }
  } else if (gameState === 'SETTINGS') {
    if (clickX >= 200 && clickX <= 600 && clickY >= 210 && clickY <= 260) {
      showTouchControls = !showTouchControls;
    } 
    else if (clickX >= 300 && clickX <= 500 && clickY >= 320 && clickY <= 365) {
      gameState = 'MENU';
      updateMusicState();
    }
  } else if (gameState === 'PAUSED') {
    if (clickX >= 280 && clickX <= 520 && clickY >= 160 && clickY <= 205) {
      gameState = 'PLAYING';
      updateMusicState();
    } 
    else if (clickX >= 280 && clickX <= 520 && clickY >= 215 && clickY <= 260) {
      restartLevel();
    }
    else if (clickX >= 280 && clickX <= 520 && clickY >= 270 && clickY <= 315) {
      gameState = 'SETTINGS';
      updateMusicState();
    } 
    else if (clickX >= 280 && clickX <= 520 && clickY >= 325 && clickY <= 370) {
      gameState = 'MENU';
      updateMusicState();
    }
  } else if (gameState === 'GAME_OVER') {
    if (clickX >= 280 && clickX <= 520 && clickY >= 220 && clickY <= 275) {
      restartLevel();
    }
    else if (clickX >= 280 && clickX <= 520 && clickY >= 290 && clickY <= 345) {
      gameState = 'MENU';
      updateMusicState();
    }
  }
}

let lastTouchTime = 0;

canvas.addEventListener('touchstart', (e) => {
  if (gameState !== 'PLAYING') {
    e.preventDefault();
    lastTouchTime = Date.now();
    const touch = e.touches[0];
    handleCanvasInteraction(touch.clientX, touch.clientY);
  }
}, { passive: false });

canvas.addEventListener('click', (e) => {
  if (Date.now() - lastTouchTime < 400) return;
  if (gameState !== 'PLAYING') {
    handleCanvasInteraction(e.clientX, e.clientY);
  }
});

// --- LÓGICA DE JUEGO Y FÍSICAS CORREGIDAS ---
function update() {
  if (btnPauseUI) {
    btnPauseUI.style.display = (gameState === 'PLAYING') ? 'flex' : 'none';
  }
  if (touchControls) {
    touchControls.style.display = (gameState === 'PLAYING' && showTouchControls) ? 'flex' : 'none';
  }

  if (gameState === 'PLAYING') {
    // 1. MOVIMIENTO Y COLISIÓN HORIZONTAL (X)
    if (keys.left) { 
      player.vx = -player.speed; 
      player.facingRight = false; 
    } else if (keys.right) { 
      player.vx = player.speed; 
      player.facingRight = true; 
    } else { 
      player.vx = 0; 
    }

    player.x += player.vx;

    for (let plat of platforms) {
      if (player.x < plat.x + plat.w && player.x + player.width > plat.x &&
          player.y < plat.y + plat.h && player.y + player.height > plat.y) {
        if (player.vx > 0) player.x = plat.x - player.width;
        else if (player.vx < 0) player.x = plat.x + plat.w;
      }
    }

    for (let b of grabables) {
      if (!b.isCarried) {
        if (player.x < b.x + b.w && player.x + player.width > b.x &&
            player.y < b.y + b.h && player.y + player.height > b.y) {
          if (player.vx > 0) player.x = b.x - player.width;
          else if (player.vx < 0) player.x = b.x + b.w;
        }
      }
    }

    if (player.x < 0) player.x = 0;
    if (player.x + player.width > levelWidth) player.x = levelWidth - player.width;

    // 2. MOVIMIENTO Y COLISIÓN VERTICAL (Y)
    player.vy += player.gravity;
    player.y += player.vy;

    player.grounded = false;

    for (let plat of platforms) {
      if (player.x < plat.x + plat.w && player.x + player.width > plat.x &&
          player.y < plat.y + plat.h && player.y + player.height > plat.y) {
        if (player.vy > 0) {
          player.y = plat.y - player.height;
          player.vy = 0;
          player.grounded = true;
          player.jumpCount = 0;
        } else if (player.vy < 0) {
          player.y = plat.y + plat.h;
          player.vy = 0;
        }
      }
    }

    for (let b of grabables) {
      if (!b.isCarried) {
        if (player.x < b.x + b.w && player.x + player.width > b.x &&
            player.y < b.y + b.h && player.y + player.height > b.y) {
          if (player.vy > 0) {
            player.y = b.y - player.height;
            player.vy = 0;
            player.grounded = true;
            player.jumpCount = 0;
          } else if (player.vy < 0) {
            player.y = b.y + b.h;
            player.vy = 0;
          }
        }
      }
    }

    // 3. CAJAS AGARRADAS Y FÍSICAS
    if (player.heldBlock) {
      player.heldBlock.x = player.facingRight ? player.x + player.width + 6 : player.x - 38;
      player.heldBlock.y = player.y + 20;
      player.heldBlock.vy = 0;
    }

    for (let b of grabables) {
      if (!b.isCarried) {
        b.vy += player.gravity;
        b.y += b.vy;

        for (let plat of platforms) {
          if (b.x < plat.x + plat.w && b.x + b.w > plat.x &&
              b.y + b.h >= plat.y && b.y + b.h <= plat.y + plat.h + Math.abs(b.vy)) {
            if (b.vy >= 0) {
              b.y = plat.y - b.h;
              b.vy = 0;
            }
          }
        }
      }
    }

    // 4. COLISIONES CON OBJETOS (TRAMPAS, MONEDAS, PUERTAS)
    for (let h of hazards) {
      if (player.x + 8 < h.x + h.w && player.x + player.width - 8 > h.x && 
          player.y + 10 < h.y + h.h && player.y + player.height > h.y + 4) {
        killPlayer(); 
        return;
      }
    }

    for (let c of coins) {
      if (!c.collected && player.x < c.x + c.w && player.x + player.width > c.x && 
          player.y < c.y + c.h && player.y + player.height > c.y) {
        c.collected = true; 
        coinsCollected++;
      }
    }

    for (let d of doors) {
      if (player.x < d.x + d.w && player.x + player.width > d.x && 
          player.y < d.y + d.h && player.y + player.height > d.y) {
        if (currentLevel < 50) {
          if (currentLevel >= gameData.unlockedLevels) {
            gameData.unlockedLevels = currentLevel + 1;
            saveGame();
          }
          loadLevelTXT(currentLevel + 1);
        } else {
          gameState = 'MENU';
        }
      }
    }

    if (player.y > canvas.height + 150) killPlayer();

    player.animTimer++;
    if (player.animTimer % 6 === 0) player.animFrame++;

    camera.x = player.x + player.width / 2 - canvas.width / 2;
    if (camera.x < 0) camera.x = 0;
    if (camera.x > levelWidth - canvas.width) camera.x = levelWidth - canvas.width;
  }
}

function drawLevel() {
  ctx.fillStyle = '#708090';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.save();
  ctx.translate(-camera.x, -camera.y);

  for (let sb of spawnBlocks) if (blockImages[8].complete) ctx.drawImage(blockImages[8], sb.x, sb.y, sb.w, sb.h);
  for (let plat of platforms) if (blockImages[plat.type].complete) ctx.drawImage(blockImages[plat.type], plat.x, plat.y, plat.w, plat.h);
  for (let d of doors) if (blockImages[d.type].complete) ctx.drawImage(blockImages[d.type], d.x, d.y, d.w, d.h);
  for (let h of hazards) if (blockImages[3].complete) ctx.drawImage(blockImages[3], h.x, h.y, h.w, h.h);
  for (let c of coins) if (!c.collected && blockImages[4].complete) ctx.drawImage(blockImages[4], c.x, c.y, c.w, c.h);

  let currentAnim = frames.idle;
  if (!player.grounded) currentAnim = frames.jump;
  else if (player.vx !== 0) currentAnim = frames.walk;

  const f = currentAnim[player.animFrame % currentAnim.length];

  ctx.save();
  ctx.imageSmoothingEnabled = false;
  if (!player.facingRight) {
    ctx.translate(player.x + player.width, player.y);
    ctx.scale(-1, 1);
    ctx.drawImage(maicolSheet, f.x, f.y, f.w, f.h, 0, 0, player.width, player.height);
  } else {
    ctx.drawImage(maicolSheet, f.x, f.y, f.w, f.h, player.x, player.y, player.width, player.height);
  }
  ctx.restore();

  for (let b of grabables) {
    if (blockImages[5].complete) {
      ctx.drawImage(blockImages[5], b.x, b.y, b.w, b.h);
      if (b.isCarried && auraImg.complete) {
        ctx.save();
        ctx.globalAlpha = 0.8;
        ctx.drawImage(auraImg, b.x - 6, b.y - 6, b.w + 12, b.h + 12);
        ctx.restore();
      }
    }
  }

  ctx.restore();

  if (blockImages[4].complete) ctx.drawImage(blockImages[4], 20, 15, 24, 24);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 20px Arial';
  ctx.textAlign = 'left';
  ctx.fillText('x ' + coinsCollected, 50, 34);
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (gameState === 'MENU') {
    ctx.fillStyle = '#5A5A5A';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'right';
    ctx.fillText('By Hola soy king orange', 770, 30);
    ctx.font = '12px Arial';
    ctx.fillText('Assets by Hola soy king orange', 770, 48);
    ctx.fillText('Inspired by BFDIA 5b', 770, 64);
    
    ctx.fillStyle = '#FFD700';
    ctx.fillText('Music: "Book Bustle" by Kevin MacLeod (incompetech.com)', 770, 82);
    ctx.fillText('Licensed under Creative Commons: By Attribution 4.0', 770, 96);

    if (logoImg.complete) ctx.drawImage(logoImg, 30, 80, 450, 280);

    if (newGameBtnImg.complete) ctx.drawImage(newGameBtnImg, 530, 180, 240, 60);
    if (continueBtnImg.complete) {
      if (!gameData.hasSavedGame) ctx.globalAlpha = 0.4;
      ctx.drawImage(continueBtnImg, 530, 250, 240, 60);
      ctx.globalAlpha = 1.0;
    }
    if (settingsBtnImg.complete) ctx.drawImage(settingsBtnImg, 530, 320, 240, 60);

  } else if (gameState === 'LEVEL_SELECT') {
    ctx.fillStyle = '#2C3E50';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('SELECT A LEVEL', canvas.width / 2, 45);

    ctx.fillStyle = '#E74C3C';
    ctx.fillRect(15, 15, 120, 45);
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.strokeRect(15, 15, 120, 45);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 18px Arial';
    ctx.fillText('◄ BACK', 75, 43);

    const startX = 100, startY = 80, btnSize = 50, gap = 12;
    for (let i = 0; i < 50; i++) {
      const col = i % 10, row = Math.floor(i / 10);
      const bx = startX + col * (btnSize + gap), by = startY + row * (btnSize + gap);
      const isUnlocked = (i + 1) <= gameData.unlockedLevels;

      ctx.fillStyle = isUnlocked ? '#3498DB' : '#7F8C8D';
      ctx.fillRect(bx, by, btnSize, btnSize);
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.strokeRect(bx, by, btnSize, btnSize);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(i + 1, bx + btnSize / 2, by + btnSize / 2 + 6);
    }

  } else if (gameState === 'SETTINGS') {
    ctx.fillStyle = '#3A3A3A';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 28px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('SETTINGS', canvas.width / 2, 80);

    ctx.fillStyle = showTouchControls ? '#2ECC71' : '#E74C3C';
    ctx.fillRect(200, 210, 400, 50);
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.strokeRect(200, 210, 400, 50);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 18px Arial';
    ctx.fillText('Mobile D-Pad: ' + (showTouchControls ? 'ENABLED (ON)' : 'DISABLED (OFF)'), canvas.width / 2, 242);

    ctx.fillStyle = '#E74C3C';
    ctx.fillRect(300, 320, 200, 45);
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.strokeRect(300, 320, 200, 45);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 18px Arial';
    ctx.fillText('◄ BACK', canvas.width / 2, 348);

  } else if (gameState === 'PLAYING') {
    drawLevel();
  } else if (gameState === 'PAUSED') {
    drawLevel();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('PAUSED', canvas.width / 2, 110);

    ctx.fillStyle = '#2ECC71';
    ctx.fillRect(280, 160, 240, 45);
    ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 2;
    ctx.strokeRect(280, 160, 240, 45);
    ctx.fillStyle = '#FFFFFF'; ctx.font = 'bold 18px Arial';
    ctx.fillText('RESUME', canvas.width / 2, 188);

    ctx.fillStyle = '#3498DB';
    ctx.fillRect(280, 215, 240, 45);
    ctx.strokeRect(280, 215, 240, 45);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText('RESTART LEVEL', canvas.width / 2, 243);

    ctx.fillStyle = '#F39C12';
    ctx.fillRect(280, 270, 240, 45);
    ctx.strokeRect(280, 270, 240, 45);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText('SETTINGS', canvas.width / 2, 298);

    ctx.fillStyle = '#E74C3C';
    ctx.fillRect(280, 325, 240, 45);
    ctx.strokeRect(280, 325, 240, 45);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText('EXIT TO MENU', canvas.width / 2, 353);

  } else if (gameState === 'GAME_OVER') {
    drawLevel();
    ctx.fillStyle = 'rgba(150, 0, 0, 0.7)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 36px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('YOU DIED!', canvas.width / 2, 150);

    ctx.fillStyle = '#2ECC71';
    ctx.fillRect(280, 220, 240, 55);
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.strokeRect(280, 220, 240, 55);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 20px Arial';
    ctx.fillText('🔄 RETRY LEVEL', canvas.width / 2, 255);

    ctx.fillStyle = '#E74C3C';
    ctx.fillRect(280, 290, 240, 55);
    ctx.strokeRect(280, 290, 240, 55);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText('EXIT TO MENU', canvas.width / 2, 325);
  }
}

function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

loop();
